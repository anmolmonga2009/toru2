package main

// type FooConfig struct {
// 	Alpha   string        `help:"a string"`
// 	Bravo   int           `help:"an int"`
// 	Charlie bool          `help:"an bool"`
// 	Delta   time.Duration `help:"a duration"`
// }

// func main() {
// 	foo := FooConfig{
// 		Bravo: 42,
// 		Delta: 2 * time.Minute,
// 	}
// 	opts.Parse(&foo)
// }
