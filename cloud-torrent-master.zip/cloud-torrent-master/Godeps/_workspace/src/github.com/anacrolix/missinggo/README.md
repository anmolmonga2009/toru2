# missinggo
[![GoDoc](https://godoc.org/github.com/anacrolix/missinggo?status.svg)](https://godoc.org/github.com/anacrolix/missinggo)

Stuff that supplements Go's stdlib, or isn't significant enough to be in its own repo.
